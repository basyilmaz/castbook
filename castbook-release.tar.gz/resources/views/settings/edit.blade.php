﻿@extends('layouts.app')

@section('content')
@php
    $logoPath = $settings['company_logo_path'] ?? null;
    $logoVersion = $settings['company_logo_version'] ?? null;
    $logoPreviewUrl = null;
    if ($logoPath) {
        $params = ['path' => $logoPath];
        if (! empty($logoVersion)) {
            $params['v'] = $logoVersion;
        }
        $logoPreviewUrl = route('settings.logo', $params);
    }
    $paymentMethodsValue = old('payment_methods');
    if ($paymentMethodsValue === null) {
        $paymentMethodsValue = implode("\n", $paymentMethods ?? []);
    }
    $invoiceNotifyValue = old('invoice_notify_recipients');
    if ($invoiceNotifyValue === null) {
        $invoiceNotifyValue = implode("\n", $invoiceNotifyRecipients ?? []);
    }
    $preview = session('backup_preview');
@endphp

<div class="container py-4">
    <div class="row mb-4">
        <div class="col">
            <h4 class="fw-semibold mb-0">Sistem Ayarları</h4>
            <small class="text-muted">Şirket bilgileri, tahsilat yöntemleri ve posta servislerini yönetin.</small>
        </div>
    </div>

    <form action="{{ route('settings.update') }}" method="POST" enctype="multipart/form-data" class="row g-4">
        @csrf
        @method('PUT')

        <div class="col-12">
            <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <h5 class="mb-0">Şirket Bilgileri</h5>
                    <div class="d-flex align-items-center gap-3">
                        <div>
                            <label class="form-label mb-1">Logo</label>
                            <input type="file" name="company_logo" class="form-control form-control-sm @error('company_logo') is-invalid @enderror">
                            @error('company_logo')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            <div class="form-text">PNG/JPG, en fazla 2 MB.</div>
                        </div>
                        <div class="text-center">
                            <span class="text-muted small d-block">Mevcut Logo</span>
                            <div class="border rounded p-2 bg-light" style="min-width:120px; min-height:80px;">
                                @if ($logoPreviewUrl)
                                    <img src="{{ $logoPreviewUrl }}" alt="Logo" class="img-fluid" style="max-height:70px;">
                                @else
                                    <span class="text-muted small">Logo yüklenmedi</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Şirket Adı</label>
                        <input type="text" name="company_name" value="{{ old('company_name', $settings['company_name'] ?? '') }}"
                               class="form-control @error('company_name') is-invalid @enderror">
                        @error('company_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Menü Başlığı</label>
                        <input type="text" name="company_menu_title"
                               value="{{ old('company_menu_title', $settings['company_menu_title'] ?? ($settings['company_name'] ?? config('app.name'))) }}"
                               class="form-control @error('company_menu_title') is-invalid @enderror">
                        @error('company_menu_title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Sol üstte logo yanında görünen ana başlık.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Şirket E-posta</label>
                        <input type="email" name="company_email" value="{{ old('company_email', $settings['company_email'] ?? '') }}"
                               class="form-control @error('company_email') is-invalid @enderror">
                        @error('company_email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Menü Alt Başlığı</label>
                        <input type="text" name="company_menu_subtitle"
                               value="{{ old('company_menu_subtitle', $settings['company_menu_subtitle'] ?? 'Kontrol Paneli') }}"
                               class="form-control @error('company_menu_subtitle') is-invalid @enderror">
                        @error('company_menu_subtitle')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Varsayılan “Kontrol Paneli” yazısını kendi markanıza göre düzenleyin.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Şirket Telefon</label>
                        <input type="text" name="company_phone" value="{{ old('company_phone', $settings['company_phone'] ?? '') }}"
                               class="form-control @error('company_phone') is-invalid @enderror">
                        @error('company_phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-12">
                        <label class="form-label">Adres</label>
                        <textarea name="company_address" rows="3"
                                  class="form-control @error('company_address') is-invalid @enderror">{{ old('company_address', $settings['company_address'] ?? '') }}</textarea>
                        @error('company_address')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Varsayılan Fatura Ayarları</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Varsayılan Açıklama</label>
                        <textarea name="invoice_default_description" rows="3"
                                  class="form-control @error('invoice_default_description') is-invalid @enderror">{{ old('invoice_default_description', $settings['invoice_default_description'] ?? '') }}</textarea>
                        @error('invoice_default_description')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Yeni faturalar oluşturulurken otomatik doldurulur.</div>
                    </div>
                    <div>
                        <label class="form-label">Vade Gün Sayısı</label>
                        <input type="number" min="0" max="365" name="invoice_default_due_days"
                               value="{{ old('invoice_default_due_days', $settings['invoice_default_due_days'] ?? '') }}"
                               class="form-control @error('invoice_default_due_days') is-invalid @enderror">
                        @error('invoice_default_due_days')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Boş bırakılırsa 10 gün olarak kabul edilir.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Tahsilat ve Bildirimler</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Tahsilat Yöntemleri</label>
                        <textarea name="payment_methods" rows="6"
                                  class="form-control @error('payment_methods') is-invalid @enderror"
                                  placeholder="Her satıra bir yöntem yazın">{{ $paymentMethodsValue }}</textarea>
                        @error('payment_methods')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Örneğin: Nakit, Banka, Kredi Kartı.</div>
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" value="1" id="invoice_auto_notify" name="invoice_auto_notify"
                               {{ old('invoice_auto_notify', $invoiceNotifyEnabled ? '1' : '0') === '1' ? 'checked' : '' }}>
                        <label class="form-check-label" for="invoice_auto_notify">
                            Aylık fatura otomasyonunda e-posta bildirimi gönder
                        </label>
                    </div>
                    <div>
                        <label class="form-label">Bildirim E-postaları</label>
                        <textarea name="invoice_notify_recipients" rows="3"
                                  class="form-control @error('invoice_notify_recipients') is-invalid @enderror"
                                  placeholder="Her satıra bir e-posta yazın">{{ $invoiceNotifyValue }}</textarea>
                        @error('invoice_notify_recipients')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        <div class="form-text">Bildirimin gideceği ekip üyeleri. Boş bırakılırsa mail gönderilmez.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Tema ve Mail</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Tema Modu</label>
                        <select name="theme_mode" class="form-select @error('theme_mode') is-invalid @enderror" required>
                            <option value="light" @selected(old('theme_mode', $settings['theme_mode'] ?? 'auto') === 'light')>Açık</option>
                            <option value="dark" @selected(old('theme_mode', $settings['theme_mode'] ?? 'auto') === 'dark')>Koyu</option>
                            <option value="auto" @selected(old('theme_mode', $settings['theme_mode'] ?? 'auto') === 'auto')>Sisteme göre</option>
                        </select>
                        @error('theme_mode')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Hazır SMTP Ayarı</label>
                        <select id="smtp_preset" name="smtp_preset" class="form-select">
                            <option value="">Manuel</option>
                            <option value="gmail" @selected(old('smtp_preset') === 'gmail')>Gmail / Google Workspace</option>
                            <option value="outlook" @selected(old('smtp_preset') === 'outlook')>Outlook / Office365</option>
                            <option value="yandex" @selected(old('smtp_preset') === 'yandex')>Yandex Mail</option>
                        </select>
                        <div id="smtpPresetHint" class="form-text">
                            Ön ayar seçildiğinde host/port alanları otomatik doldurulur. Kimlik bilgilerinizi elle girmeniz gerekir.
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">SMTP Sunucusu</label>
                        <input type="text" name="mail_host" value="{{ old('mail_host', $settings['mail_host'] ?? '') }}"
                               class="form-control @error('mail_host') is-invalid @enderror" placeholder="smtp.ornek.com">
                        @error('mail_host')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col">
                            <label class="form-label">Port</label>
                            <input type="number" name="mail_port" value="{{ old('mail_port', $settings['mail_port'] ?? '') }}"
                                   class="form-control @error('mail_port') is-invalid @enderror" placeholder="587">
                            @error('mail_port')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col">
                            <label class="form-label">Şifreleme</label>
                            <input type="text" name="mail_encryption" value="{{ old('mail_encryption', $settings['mail_encryption'] ?? '') }}"
                                   class="form-control @error('mail_encryption') is-invalid @enderror" placeholder="tls / ssl">
                            @error('mail_encryption')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Kullanıcı Adı</label>
                        <input type="text" name="mail_username" value="{{ old('mail_username', $settings['mail_username'] ?? '') }}"
                               class="form-control @error('mail_username') is-invalid @enderror">
                        @error('mail_username')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Şifre</label>
                        <input type="password" name="mail_password" value="{{ old('mail_password', $settings['mail_password'] ?? '') }}"
                               class="form-control @error('mail_password') is-invalid @enderror" autocomplete="new-password">
                        @error('mail_password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Gönderici E-posta</label>
                        <input type="email" name="mail_from_address" value="{{ old('mail_from_address', $settings['mail_from_address'] ?? '') }}"
                               class="form-control @error('mail_from_address') is-invalid @enderror">
                        @error('mail_from_address')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div>
                        <label class="form-label">Gönderici Adı</label>
                        <input type="text" name="mail_from_name" value="{{ old('mail_from_name', $settings['mail_from_name'] ?? config('app.name')) }}"
                               class="form-control @error('mail_from_name') is-invalid @enderror">
                        @error('mail_from_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body d-flex justify-content-end gap-2">
                    <a href="{{ route('dashboard') }}" class="btn btn-light">İptal</a>
                    <button type="submit" class="btn btn-primary">Ayarları Kaydet</button>
                </div>
            </div>
        </div>
    </form>

    <div class="row g-4 mt-1">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Yedekleme / CSV</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <p class="text-muted small mb-2">Mevcut veritabanınızı JSON formatında indirin veya daha önce alınan yedeği geri yükleyin.</p>
                        <form action="{{ route('settings.backup.download') }}" method="POST" class="row gy-2 gx-0 align-items-center mb-3">
                            @csrf
                            <div class="col-12 col-md-auto me-md-2">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">Şifre (opsiyonel)</span>
                                    <input type="password" name="password" class="form-control" placeholder="En az 4 karakter">
                                </div>
                            </div>
                            <div class="col-12 col-md-auto">
                                <button type="submit" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-download me-1"></i>Yedek İndir
                                </button>
                            </div>
                            <div class="col-12">
                                <span class="text-muted small">Şifre girerseniz yedek AES-256-GCM ile şifrelenecektir.</span>
                            </div>
                        </form>
                        <form action="{{ route('settings.backup.restore') }}" method="POST" enctype="multipart/form-data" class="row gy-2 gx-0 align-items-center">
                            @csrf
                            <div class="col-12 col-lg-auto me-lg-2">
                                <input type="file" name="backup_file" accept=".json" class="form-control form-control-sm @error('backup_file') is-invalid @enderror" required>
                                @error('backup_file')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12 col-md-4 col-lg-3">
                                <input type="password" name="restore_password" class="form-control form-control-sm @error('restore_password') is-invalid @enderror" placeholder="Şifre (varsa)">
                                @error('restore_password')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12 col-md d-flex align-items-center">
                                <div class="form-check me-3">
                                    <input class="form-check-input @error('confirm_restore') is-invalid @enderror" type="checkbox" value="1" id="confirm_restore" name="confirm_restore" {{ old('confirm_restore') ? 'checked' : '' }}>
                                    <label class="form-check-label small" for="confirm_restore">
                                        Geri yükleme öncesi verilerin tamamen silineceğini onaylıyorum.
                                    </label>
                                    @error('confirm_restore')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                                </div>
                                <div class="ms-auto d-flex gap-2">
                                    <button type="submit" name="mode" value="preview" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-search me-1"></i>Yedeği Analiz Et
                                    </button>
                                    <button type="submit" name="mode" value="restore" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-arrow-counterclockwise me-1"></i>Yedeği Geri Yükle
                                    </button>
                                </div>
                            </div>
                        </form>
                        <p class="text-danger small mt-2 mb-0">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i>
                            Bu işlem mevcut firmalar, faturalar, tahsilatlar, işlemler ve ayarları siler; yalnızca doğrulanmış yedekleri yükleyin.
                        </p>
                    </div>
                    @includeWhen($preview, 'settings.partials.backup-preview', ['preview' => $preview])
                    <hr>
                    <p class="text-muted small mb-2">Hızlı CSV dışa aktarımlar:</p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="{{ route('settings.export.csv', 'firms') }}" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-file-earmark-arrow-down"></i> Firmalar CSV
                        </a>
                        <a href="{{ route('settings.export.csv', 'invoices') }}" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-file-earmark-arrow-down"></i> Faturalar CSV
                        </a>
                        <a href="{{ route('settings.export.csv', 'payments') }}" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-file-earmark-arrow-down"></i> Tahsilatlar CSV
                        </a>
                    </div>
                    <p class="text-muted small mt-3 mb-0">Not: CSV geri yükleme desteği ilerleyen sürümlerde eklenecektir.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const presetSelect = document.getElementById('smtp_preset');
        if (!presetSelect) {
            return;
        }

        const hostInput = document.querySelector('input[name="mail_host"]');
        const portInput = document.querySelector('input[name="mail_port"]');
        const encryptionInput = document.querySelector('input[name="mail_encryption"]');
        const hintEl = document.getElementById('smtpPresetHint');

        const presets = {
            gmail: {
                host: 'smtp.gmail.com',
                port: '587',
                encryption: 'tls',
                hint: 'Gmail için uygulama şifresi oluşturmanız gerekir (Google Hesap > Güvenlik > Uygulama şifreleri). Gönderici e-postası olarak Gmail adresinizi kullanın.'
            },
            outlook: {
                host: 'smtp.office365.com',
                port: '587',
                encryption: 'tls',
                hint: 'Outlook / Office365 için çok faktörlü kimlik doğrulama varsa uygulama parolası kullanın. Gönderici e-postasının Exchange hesabında yetkili olduğundan emin olun.'
            },
            yandex: {
                host: 'smtp.yandex.com',
                port: '465',
                encryption: 'ssl',
                hint: 'Yandex Mail için POP/IMAP SMTP erişimini etkinleştirin. İki aşamalı doğrulama açıksa uygulama şifresi gerekir.'
            }
        };

        const applyPreset = (key) => {
            const preset = presets[key];
            if (!preset) {
                if (hintEl) {
                    hintEl.textContent = 'Ön ayar seçildiğinde host/port alanları otomatik doldurulur. Kimlik bilgilerinizi elle girmeniz gerekir.';
                }
                return;
            }

            if (hostInput) hostInput.value = preset.host;
            if (portInput) portInput.value = preset.port;
            if (encryptionInput) encryptionInput.value = preset.encryption;
            if (hintEl) hintEl.textContent = preset.hint;
        };

        presetSelect.addEventListener('change', function () {
            applyPreset(this.value);
        });

        if (presetSelect.value) {
            applyPreset(presetSelect.value);
        }
    });
</script>
@endsection
