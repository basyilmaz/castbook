<!DOCTYPE html>
<html lang="tr" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'CastBook') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script>
        document.documentElement.classList.remove('no-js');
    </script>
</head>
@php
    $appName = config('app.name', 'CastBook');
    $companyName = ($layoutCompanyName ?? $appName) ?: $appName;
    $companyInitial = $layoutCompanyInitial ?? mb_strtoupper(mb_substr($companyName, 0, 1));
    $logoUrl = $layoutLogoUrl ?? null;
    $themeMode = $layoutThemeMode ?? 'auto';
    $isAdmin = $layoutIsAdmin ?? false;
    $menuTitle = ($layoutMenuTitle ?? $companyName) ?: $companyName;
    $menuSubtitle = $layoutMenuSubtitle ?? null;
@endphp
<body class="min-vh-100" data-theme-mode="{{ $themeMode }}">
    <nav class="navbar navbar-expand-lg navbar-dark app-navbar">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-3" href="{{ route('dashboard') }}">
                <span class="brand-logo-wrapper">
                    @if ($logoUrl)
                        <img src="{{ $logoUrl }}" alt="Logo" class="brand-logo-img">
                    @else
                        <span class="brand-logo-placeholder">{{ $companyInitial }}</span>
                    @endif
                </span>
                <span class="brand-text d-flex flex-column">
                    <span class="brand-title">{{ $menuTitle }}</span>
                    @if(! empty($menuSubtitle))
                        <span class="brand-subtitle d-none d-md-block">{{ $menuSubtitle }}</span>
                    @endif
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNav"
                aria-controls="topNav" aria-expanded="false" aria-label="Menüyü aç/kapa">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="topNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"
                           href="{{ route('dashboard') }}">Genel Bakış</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('firms.*') ? 'active' : '' }}"
                           href="{{ route('firms.index') }}">Firmalar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('invoices.*') ? 'active' : '' }}"
                           href="{{ route('invoices.index') }}">Faturalar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('payments.*') ? 'active' : '' }}"
                           href="{{ route('payments.index') }}">Tahsilatlar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('reports.*') ? 'active' : '' }}"
                           href="{{ route('reports.balance') }}">Raporlar</a>
                    </li>
                    @if($isAdmin)
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}"
                               href="{{ route('users.index') }}">Kullanıcılar</a>
                        </li>
                    @endif
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('settings.*') ? 'active' : '' }}"
                           href="{{ route('settings.edit') }}">Ayarlar</a>
                    </li>
                </ul>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="btn btn-outline-light btn-sm">
                        Çıkış Yap
                    </button>
                </form>
            </div>
        </div>
    </nav>
    <main class="container py-4">
        @if (session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
        @endif
        @if (session('warning'))
            <div class="alert alert-warning">{{ session('warning') }}</div>
        @endif

        @yield('content')
    </main>
</body>
</html>
