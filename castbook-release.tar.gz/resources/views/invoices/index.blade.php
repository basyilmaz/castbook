@extends('layouts.app')

@php
    use App\Support\Format;

    $statusOptions = [
        '' => 'Tümü',
        'unpaid' => 'Ödenmedi',
        'partial' => 'Kısmi Ödeme',
        'paid' => 'Ödendi',
        'cancelled' => 'İptal',
    ];
@endphp

@section('content')
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div>
            <h4 class="fw-semibold mb-0">Faturalar</h4>
            <small class="text-muted">Faturalarınızı filtreleyip yönetin.</small>
        </div>
        <div class="d-flex flex-column flex-sm-row gap-2 mt-3 mt-md-0">
            <form action="{{ route('invoices.sync-monthly') }}" method="POST" class="d-flex align-items-center gap-2">
                @csrf
                <input type="month" name="month" class="form-control form-control-sm" value="{{ now()->format('Y-m') }}">
                <button type="submit" class="btn btn-sm btn-outline-warning">
                    <i class="bi bi-arrow-repeat me-1"></i> Aylık Fatura Üret
                </button>
            </form>
            <a href="{{ route('invoices.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-lg me-1"></i> Yeni Fatura Oluştur
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form action="{{ route('invoices.index') }}" method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label text-muted text-uppercase small">Firma</label>
                    <select name="firm_id" class="form-select">
                        <option value="">Tümü</option>
                        @foreach ($firms as $firm)
                            <option value="{{ $firm->id }}" @selected(($filters['firm_id'] ?? null) == $firm->id)>
                                {{ $firm->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label text-muted text-uppercase small">Durum</label>
                    <select name="status" class="form-select">
                        @foreach ($statusOptions as $value => $label)
                            <option value="{{ $value }}" @selected(($filters['status'] ?? '') === $value)>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label text-muted text-uppercase small">Tarih Aralığı</label>
                    <div class="d-flex gap-2">
                        <input type="date" name="date_from" class="form-control" value="{{ $filters['date_from'] ?? '' }}">
                        <input type="date" name="date_to" class="form-control" value="{{ $filters['date_to'] ?? '' }}">
                    </div>
                </div>
                <div class="col-md-2">
                    <label class="form-label text-muted text-uppercase small">Sayfa Boyutu</label>
                    <select name="per_page" class="form-select" onchange="this.form.submit()">
                        @foreach ([10, 20, 50, 100] as $size)
                            <option value="{{ $size }}" @selected(($filters['per_page'] ?? $perPage) == $size)>{{ $size }} / sayfa</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 d-flex justify-content-end gap-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-funnel-fill me-1"></i> Filtrele
                    </button>
                    <a href="{{ route('invoices.index', ['per_page' => $perPage]) }}" class="btn btn-outline-secondary">Temizle</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Fatura No</th>
                            <th>Firma</th>
                            <th>Tarih</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-end">Ödenen</th>
                            <th class="text-end">Kalan</th>
                            <th class="text-center">Durum</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($invoices as $invoice)
                            @php
                                $paid = (float) ($invoice->payments_sum_amount ?? 0);
                                $remaining = max(0, (float) $invoice->amount - $paid);
                                $statusMeta = match ($invoice->status) {
                                    'paid' => ['label' => 'Ödendi', 'class' => 'success'],
                                    'partial' => ['label' => 'Kısmi Ödeme', 'class' => 'warning text-dark'],
                                    'cancelled' => ['label' => 'İptal', 'class' => 'secondary'],
                                    default => ['label' => 'Ödenmedi', 'class' => 'danger'],
                                };
                            @endphp
                            <tr>
                                <td>
                                    <div class="fw-semibold">#{{ $invoice->id }}</div>
                                    @if ($invoice->official_number)
                                        <small class="text-muted">{{ $invoice->official_number }}</small>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('firms.show', $invoice->firm) }}" class="text-decoration-none">
                                        {{ $invoice->firm->name }}
                                    </a>
                                </td>
                                <td>{{ $invoice->date?->format('d.m.Y') }}</td>
                                <td class="text-end">{{ Format::money($invoice->amount) }}</td>
                                <td class="text-end text-success">{{ Format::money($paid) }}</td>
                                <td class="text-end {{ $remaining > 0 ? 'text-danger' : 'text-muted' }}">
                                    {{ Format::money($remaining) }}
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-{{ $statusMeta['class'] }}">
                                        {{ $statusMeta['label'] }}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="{{ route('invoices.show', $invoice) }}" class="btn btn-sm btn-outline-secondary me-1">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <form action="{{ route('invoices.destroy', $invoice) }}" method="POST" class="d-inline"
                                          onsubmit="return confirm('Bu faturayı silmek istediğinize emin misiniz?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    Görüntülenecek fatura bulunamadı.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white">
            <div class="row g-2 align-items-center justify-content-between">
                <div class="col-md-6 text-muted small">
                    @if ($invoices->total() > 0)
                        {{ $invoices->firstItem() }} - {{ $invoices->lastItem() }} arası gösteriliyor. Toplam {{ $invoices->total() }} kayıt.
                    @else
                        Kayıt bulunamadı.
                    @endif
                </div>
                <div class="col-md-6">
                    {{ $invoices->onEachSide(1)->appends(['per_page' => $perPage] + $filters)->links('vendor.pagination.bootstrap-5-tr') }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
