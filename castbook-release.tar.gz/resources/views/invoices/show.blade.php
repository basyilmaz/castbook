@extends('layouts.app')

@php
    use App\Support\Format;

    $paidTotal = (float) ($invoice->payments_sum_amount ?? $invoice->payments->sum('amount'));
    $remaining = max(0, (float) $invoice->amount - $paidTotal);
    $statusMeta = match ($invoice->status) {
        'paid' => ['label' => 'Ödendi', 'class' => 'success'],
        'partial' => ['label' => 'Kısmi Ödeme', 'class' => 'warning text-dark'],
        'cancelled' => ['label' => 'İptal', 'class' => 'secondary'],
        default => ['label' => 'Ödenmedi', 'class' => 'danger'],
    };
@endphp

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h4 class="mb-0">Fatura #{{ $invoice->id }}</h4>
        <small class="text-muted">{{ $invoice->firm->name }}</small>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('payments.create', ['invoice_id' => $invoice->id, 'firm_id' => $invoice->firm_id]) }}"
           class="btn btn-sm btn-outline-success">
            Tahsilat Kaydet
        </a>
        @if (! in_array($invoice->status, ['paid', 'partial'], true))
            <a href="{{ route('invoices.edit', $invoice) }}" class="btn btn-sm btn-secondary">Düzenle</a>
        @endif
        <a href="{{ route('invoices.index') }}" class="btn btn-sm btn-light">Listeye Dön</a>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted text-uppercase small">Durum</span>
                    <span class="badge bg-{{ $statusMeta['class'] }}">{{ $statusMeta['label'] }}</span>
                </div>
                <div class="mb-2">
                    <small class="text-muted d-block">Fatura Tarihi</small>
                    <span class="fw-semibold">{{ $invoice->date?->format('d.m.Y') ?? '-' }}</span>
                </div>
                <div class="mb-2">
                    <small class="text-muted d-block">Vade Tarihi</small>
                    <span class="fw-semibold">{{ $invoice->due_date?->format('d.m.Y') ?? '-' }}</span>
                </div>
                <hr>
                <div class="mb-2">
                    <small class="text-muted d-block">Resmi Fatura No</small>
                    <span class="fw-semibold">{{ $invoice->official_number ?? '-' }}</span>
                </div>
                <div class="mb-2">
                    <small class="text-muted d-block">Fatura Tutarı</small>
                    <span class="h5 mb-0">{{ Format::money($invoice->amount) }}</span>
                </div>
                <div class="mb-2">
                    <small class="text-muted d-block">Ödenen</small>
                    <span class="fw-semibold text-success">{{ Format::money($paidTotal) }}</span>
                </div>
                <div class="mb-2">
                    <small class="text-muted d-block">Kalan</small>
                    <span class="fw-semibold {{ $remaining > 0 ? 'text-danger' : 'text-muted' }}">
                        {{ Format::money($remaining) }}
                    </span>
                </div>
                <hr>
                <div class="mb-2">
                    <small class="text-muted d-block">Açıklama</small>
                    <span>{{ $invoice->description ?? '-' }}</span>
                </div>
                <div class="mb-0">
                    <small class="text-muted d-block">Ödeme Tarihi</small>
                    <span>{{ $invoice->paid_at?->format('d.m.Y H:i') ?? '-' }}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Tahsilatlar</h6>
                <small class="text-muted">{{ $invoice->payments->count() }} kayıt</small>
            </div>
            <div class="card-body p-0">
                @if ($invoice->payments->isEmpty())
                    <p class="text-center text-muted py-4 mb-0">Bu faturaya bağlı tahsilat bulunmuyor.</p>
                @else
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Yöntem</th>
                                    <th class="text-end">Tutar</th>
                                    <th>Not</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($invoice->payments as $payment)
                                    <tr>
                                        <td>{{ $payment->date?->format('d.m.Y') }}</td>
                                        <td>{{ $payment->method ?? '-' }}</td>
                                        <td class="text-end">{{ Format::money($payment->amount) }}</td>
                                        <td>{{ $payment->note ?? '-' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
