@php
    use App\Support\Format;
@endphp

<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label" for="firm_id">Firma</label>
        <select class="form-select @error('firm_id') is-invalid @enderror" id="firm_id" name="firm_id" required>
            <option value="">Firma seçin</option>
            @foreach ($firms as $firm)
                <option value="{{ $firm->id }}"
                    @selected(old('firm_id', $invoice->firm_id ?? $prefillFirmId ?? null) == $firm->id)>
                    {{ $firm->name }} ({{ Format::money($firm->monthly_fee) }})
                </option>
            @endforeach
        </select>
        @error('firm_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-3">
        <label class="form-label" for="date">Fatura Tarihi</label>
        <input type="date" class="form-control @error('date') is-invalid @enderror" id="date" name="date"
               value="{{ old('date', optional($invoice->date)->format('Y-m-d')) }}" required>
        @error('date')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-3">
        <label class="form-label" for="due_date">Vade Tarihi</label>
        <input type="date" class="form-control @error('due_date') is-invalid @enderror" id="due_date" name="due_date"
               value="{{ old('due_date', optional($invoice->due_date)->format('Y-m-d')) }}">
        @error('due_date')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="amount">Tutar (₺)</label>
        <input type="number" step="0.01" min="0" class="form-control @error('amount') is-invalid @enderror"
               id="amount" name="amount" value="{{ old('amount', $invoice->amount) }}" required>
        @error('amount')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="official_number">Resmi Fatura No</label>
        <input type="text" class="form-control @error('official_number') is-invalid @enderror"
               id="official_number" name="official_number" maxlength="50"
               value="{{ old('official_number', $invoice->official_number) }}">
        @error('official_number')<div class="invalid-feedback">{{ $message }}</div>@enderror
        <div class="form-text">Opsiyonel. Örn: 2024-00125</div>
    </div>
    <div class="col-md-8">
        <label class="form-label" for="description">Açıklama</label>
        <input type="text" class="form-control @error('description') is-invalid @enderror"
               id="description" name="description" value="{{ old('description', $invoice->description) }}">
        @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>
