<?php
    use App\Support\Format;
?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <h4 class="mb-0">Müşteri Bazında Bakiye</h4>
    <small class="text-muted">Borç / alacak dağılımı ve güncel bakiyeler.</small>
</div>

<?php echo $__env->make('reports._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<form method="GET" class="card border-0 shadow-sm mb-3">
    <div class="card-body row g-3 align-items-end">
        <div class="col-md-4">
            <label for="status" class="form-label">Durum</label>
            <select name="status" id="status" class="form-select">
                <option value="">Tümü</option>
                <option value="active" <?php if($status === 'active'): echo 'selected'; endif; ?>>Aktif</option>
                <option value="inactive" <?php if($status === 'inactive'): echo 'selected'; endif; ?>>Pasif</option>
            </select>
        </div>
        <div class="col-md-3">
            <label for="per_page" class="form-label">Sayfa Başına Kayıt</label>
            <select name="per_page" id="per_page" class="form-select">
                <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($size); ?>" <?php if($perPage === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-grid gap-2">
            <button type="submit" class="btn btn-primary">Filtrele</button>
            <a href="<?php echo e(route('reports.balance')); ?>" class="btn btn-light">Temizle</a>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Toplam Borç</small>
                <div class="h4 mb-0 text-danger"><?php echo e(Format::money($totals['debit'])); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Toplam Tahsilat</small>
                <div class="h4 mb-0 text-success"><?php echo e(Format::money($totals['credit'])); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Net Bakiye</small>
                <div class="h4 mb-0 <?php echo e($totals['balance'] > 0 ? 'text-danger' : ($totals['balance'] < 0 ? 'text-success' : '')); ?>">
                    <?php echo e(Format::money($totals['balance'])); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Firma</th>
                        <th>Durum</th>
                        <th class="text-end">Borç</th>
                        <th class="text-end">Tahsilat</th>
                        <th class="text-end">Bakiye</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $firms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $balance = $firm->balance_total; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('firms.show', $firm)); ?>" class="text-decoration-none fw-semibold">
                                    <?php echo e($firm->name); ?>

                                </a>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($firm->status === 'active' ? 'success' : 'secondary'); ?>">
                                    <?php echo e($firm->status === 'active' ? 'Aktif' : 'Pasif'); ?>

                                </span>
                            </td>
                            <td class="text-end text-danger"><?php echo e(Format::money($firm->debit_total)); ?></td>
                            <td class="text-end text-success"><?php echo e(Format::money($firm->credit_total)); ?></td>
                            <td class="text-end <?php echo e($balance > 0 ? 'text-danger' : ($balance < 0 ? 'text-success' : '')); ?>">
                                <?php echo e(Format::money($balance)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                Kayıt bulunamadı.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer bg-white">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div class="text-muted small">
                Toplam <?php echo e($firms->total()); ?> kayıt · Sayfa <?php echo e($firms->currentPage()); ?> / <?php echo e($firms->lastPage()); ?>

            </div>
            <?php echo e($firms->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/reports/balances.blade.php ENDPATH**/ ?>