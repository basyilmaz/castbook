<!DOCTYPE html>
<html lang="tr" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'CastBook')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script>
        document.documentElement.classList.remove('no-js');
    </script>
</head>
<?php
    $appName = config('app.name', 'CastBook');
    $companyName = ($layoutCompanyName ?? $appName) ?: $appName;
    $companyInitial = $layoutCompanyInitial ?? mb_strtoupper(mb_substr($companyName, 0, 1));
    $logoUrl = $layoutLogoUrl ?? null;
    $themeMode = $layoutThemeMode ?? 'auto';
    $isAdmin = $layoutIsAdmin ?? false;
    $menuTitle = ($layoutMenuTitle ?? $companyName) ?: $companyName;
    $menuSubtitle = $layoutMenuSubtitle ?? null;
?>
<body class="min-vh-100" data-theme-mode="<?php echo e($themeMode); ?>">
    <nav class="navbar navbar-expand-lg navbar-dark app-navbar">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-3" href="<?php echo e(route('dashboard')); ?>">
                <span class="brand-logo-wrapper">
                    <?php if($logoUrl): ?>
                        <img src="<?php echo e($logoUrl); ?>" alt="Logo" class="brand-logo-img">
                    <?php else: ?>
                        <span class="brand-logo-placeholder"><?php echo e($companyInitial); ?></span>
                    <?php endif; ?>
                </span>
                <span class="brand-text d-flex flex-column">
                    <span class="brand-title"><?php echo e($menuTitle); ?></span>
                    <?php if(! empty($menuSubtitle)): ?>
                        <span class="brand-subtitle d-none d-md-block"><?php echo e($menuSubtitle); ?></span>
                    <?php endif; ?>
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNav"
                aria-controls="topNav" aria-expanded="false" aria-label="Menüyü aç/kapa">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="topNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"
                           href="<?php echo e(route('dashboard')); ?>">Genel Bakış</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('firms.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('firms.index')); ?>">Firmalar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('invoices.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('invoices.index')); ?>">Faturalar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('payments.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('payments.index')); ?>">Tahsilatlar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('reports.balance')); ?>">Raporlar</a>
                    </li>
                    <?php if($isAdmin): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>"
                               href="<?php echo e(route('users.index')); ?>">Kullanıcılar</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.edit')); ?>">Ayarlar</a>
                    </li>
                </ul>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">
                        Çıkış Yap
                    </button>
                </form>
            </div>
        </div>
    </nav>
    <main class="container py-4">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if(session('warning')): ?>
            <div class="alert alert-warning"><?php echo e(session('warning')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/layouts/app.blade.php ENDPATH**/ ?>