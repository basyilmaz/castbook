<?php
    use App\Support\Format;
?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div>
            <h4 class="fw-semibold mb-0">Firmalar</h4>
            <small class="text-muted">Müşteri listesi, durum ve aylık ücret bilgileri.</small>
        </div>
        <a href="<?php echo e(route('firms.create')); ?>" class="btn btn-primary mt-3 mt-md-0">
            <i class="bi bi-plus-lg me-1"></i> Yeni Firma Ekle
        </a>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('firms.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label text-muted text-uppercase small" for="search">Arama</label>
                    <input type="text" name="search" id="search" class="form-control" placeholder="Firma adı, vergi no veya e-posta"
                           value="<?php echo e($search); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-muted text-uppercase small" for="per_page">Sayfa Boyutu</label>
                    <select name="per_page" id="per_page" class="form-select" onchange="this.form.submit()">
                        <?php $__currentLoopData = [10, 20, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($size); ?>" <?php if($perPage == $size): echo 'selected'; endif; ?>><?php echo e($size); ?> / sayfa</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">
                        <i class="bi bi-search me-1"></i> Ara
                    </button>
                    <a href="<?php echo e(route('firms.index')); ?>" class="btn btn-outline-secondary">Temizle</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Firma Adı</th>
                            <th>Vergi No</th>
                            <th class="text-end">Aylık Ücret</th>
                            <th>E-posta</th>
                            <th>Durum</th>
                            <th class="text-end">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $firms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('firms.show', $firm)); ?>" class="text-decoration-none fw-semibold">
                                        <?php echo e($firm->name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($firm->tax_no ?? '-'); ?></td>
                                <td class="text-end"><?php echo e(Format::money($firm->monthly_fee)); ?></td>
                                <td><?php echo e($firm->contact_email ?? '-'); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($firm->status === 'active' ? 'success' : 'secondary'); ?>">
                                        <?php echo e($firm->status === 'active' ? 'Aktif' : 'Pasif'); ?>

                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('firms.edit', $firm)); ?>" class="btn btn-sm btn-outline-secondary me-1">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('firms.destroy', $firm)); ?>" method="POST" class="d-inline"
                                          onsubmit="return confirm('Firmayı arşivlemek istediğinize emin misiniz?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-archive"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">Görüntülenecek firma bulunamadı.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white">
            <div class="row g-2 align-items-center justify-content-between">
                <div class="col-md-6 text-muted small">
                    <?php if($firms->total() > 0): ?>
                        <?php echo e($firms->firstItem()); ?> - <?php echo e($firms->lastItem()); ?> arası gösteriliyor. Toplam <?php echo e($firms->total()); ?> kayıt.
                    <?php else: ?>
                        Kayıt bulunamadı.
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php echo e($firms->onEachSide(1)->appends(['search' => $search, 'per_page' => $perPage])->links('vendor.pagination.bootstrap-5-tr')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/firms/index.blade.php ENDPATH**/ ?>