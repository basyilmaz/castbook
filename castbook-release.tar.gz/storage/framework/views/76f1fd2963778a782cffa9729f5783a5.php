<?php
    $tabs = [
        'reports.balance' => 'Müşteri Bakiyeleri',
        'reports.collections' => 'Aylık Tahsilat',
        'reports.overdues' => 'Geciken Ödemeler',
        'reports.invoices' => 'Fatura Durumu',
    ];
?>

<ul class="nav nav-pills mb-3">
    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs($route) ? 'active' : ''); ?>"
               href="<?php echo e(route($route)); ?>">
                <?php echo e($label); ?>

            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/reports/_tabs.blade.php ENDPATH**/ ?>