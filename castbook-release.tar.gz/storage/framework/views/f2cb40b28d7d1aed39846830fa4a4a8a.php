<?php
    use App\Support\Format;

    $currentPrice = $firm->priceForDate(now());
    $balance = $firm->balance;
?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center mb-3 gap-3">
    <div>
        <h4 class="mb-0"><?php echo e($firm->name); ?></h4>
        <small class="text-muted">Firma detayları, fiyat geçmişi ve cari hareketler</small>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <form action="<?php echo e(route('firms.sync-invoices', $firm)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-outline-warning">
                Geçmiş Borçları Senkronize Et
            </button>
        </form>
        <a href="<?php echo e(route('invoices.create', ['firm_id' => $firm->id])); ?>" class="btn btn-sm btn-outline-primary">
            Fatura Oluştur
        </a>
        <a href="<?php echo e(route('payments.create', ['firm_id' => $firm->id])); ?>" class="btn btn-sm btn-outline-success">
            Tahsilat Ekle
        </a>
        <a href="<?php echo e(route('firms.edit', $firm)); ?>" class="btn btn-sm btn-secondary">
            Düzenle
        </a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-3 col-sm-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Geçerli Aylık Ücret</small>
                <div class="h4 mb-0"><?php echo e(Format::money($currentPrice)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-sm-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Sözleşme Başlangıç</small>
                <div class="h4 mb-0"><?php echo e($firm->contract_start_at?->format('d.m.Y') ?? '-'); ?></div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-sm-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Son Senkron</small>
                <div class="h6 mb-0"><?php echo e($firm->initial_debt_synced_at?->format('d.m.Y H:i') ?? 'Henüz çalıştırılmadı'); ?></div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-sm-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Güncel Bakiye</small>
                <div class="h4 mb-0 <?php echo e($balance > 0 ? 'text-danger' : ($balance < 0 ? 'text-success' : '')); ?>">
                    <?php echo e(Format::money($balance)); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white">
                <h6 class="mb-0">İletişim Bilgileri</h6>
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-5 text-muted">Vergi No</dt>
                    <dd class="col-7"><?php echo e($firm->tax_no ?? '-'); ?></dd>

                    <dt class="col-5 text-muted">Yetkili</dt>
                    <dd class="col-7"><?php echo e($firm->contact_person ?? '-'); ?></dd>

                    <dt class="col-5 text-muted">E-Posta</dt>
                    <dd class="col-7"><?php echo e($firm->contact_email ?? '-'); ?></dd>

                    <dt class="col-5 text-muted">Telefon</dt>
                    <dd class="col-7"><?php echo e($firm->contact_phone ?? '-'); ?></dd>

                    <dt class="col-5 text-muted">Durum</dt>
                    <dd class="col-7">
                        <span class="badge bg-<?php echo e($firm->status === 'active' ? 'success' : 'secondary'); ?>">
                            <?php echo e($firm->status === 'active' ? 'Aktif' : 'Pasif'); ?>

                        </span>
                    </dd>
                </dl>
                <?php if($firm->notes): ?>
                    <hr>
                    <h6 class="text-muted text-uppercase small">Notlar</h6>
                    <p class="mb-0"><?php echo e($firm->notes); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Fiyat Geçmişi</h6>
                <small class="text-muted">Zam dönemlerini yönetin</small>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('firms.price-histories.store', $firm)); ?>" method="POST" class="row g-2 align-items-end mb-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-6">
                        <label class="form-label">Başlangıç Tarihi</label>
                        <input type="date" name="valid_from" value="<?php echo e(old('valid_from', now()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['valid_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['valid_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <label class="form-label">Ücret (₺)</label>
                        <input type="number" step="0.01" min="0" name="amount" value="<?php echo e(old('amount', $firm->monthly_fee)); ?>"
                               class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 d-grid">
                        <button type="submit" class="btn btn-outline-primary btn-sm">Fiyat Dönemi Ekle</button>
                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table table-sm align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Başlangıç</th>
                                <th class="text-end">Ücret</th>
                                <th class="text-end">İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $firm->priceHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($history->valid_from?->format('d.m.Y')); ?></td>
                                    <td class="text-end"><?php echo e(Format::money($history->amount)); ?></td>
                                    <td class="text-end">
                                        <form action="<?php echo e(route('firms.price-histories.destroy', [$firm, $history])); ?>" method="POST"
                                              onsubmit="return confirm('Bu fiyat kaydını silmek istediğinize emin misiniz?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-2">Tanımlı fiyat geçmişi bulunmuyor.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Hesap Ekstresi</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('firms.statement', $firm)); ?>" method="POST" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-6">
                        <label class="form-label">Başlangıç</label>
                        <input type="date" name="start_date" value="<?php echo e(old('start_date', now()->startOfMonth()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-6">
                        <label class="form-label">Bitiş</label>
                        <input type="date" name="end_date" value="<?php echo e(old('end_date', now()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-12">
                        <label class="form-label">Gönderim E-postası</label>
                        <input type="email" name="send_to" value="<?php echo e(old('send_to', $firm->contact_email)); ?>"
                               class="form-control <?php $__errorArgs = ['send_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="E-posta (opsiyonel)">
                        <?php $__errorArgs = ['send_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-12 d-flex gap-2 justify-content-sm-end">
                        <button type="submit" name="action" value="download" class="btn btn-outline-secondary">
                            <i class="bi bi-file-earmark-pdf me-1"></i> PDF İndir
                        </button>
                        <button type="submit" name="action" value="email" class="btn btn-outline-primary">
                            <i class="bi bi-envelope-at me-1"></i> E-posta Gönder
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Cari Hareketler</h6>
                <small class="text-muted">Toplam <?php echo e($firm->transactions->count()); ?> kayıt</small>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <div class="p-3 border rounded text-center">
                            <div class="text-muted text-uppercase small">Toplam Borç</div>
                            <div class="h5 text-danger mb-0"><?php echo e(Format::money($debitTotal)); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 border rounded text-center">
                            <div class="text-muted text-uppercase small">Toplam Tahsilat</div>
                            <div class="h5 text-success mb-0"><?php echo e(Format::money($creditTotal)); ?></div>
                        </div>
                    </div>
                </div>

                <?php if($firm->transactions->isEmpty()): ?>
                    <p class="text-center text-muted mb-0">Henüz hareket bulunmuyor.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Açıklama</th>
                                    <th>Tip</th>
                                    <th class="text-end">Tutar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $firm->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->date?->format('d.m.Y')); ?></td>
                                        <td>
                                            <?php echo e($transaction->description); ?>

                                            <?php if($transaction->sourceable): ?>
                                                <span class="badge bg-light text-dark ms-2">
                                                    <?php echo e(class_basename($transaction->sourceable)); ?> #<?php echo e($transaction->sourceable->id); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($transaction->type === 'debit' ? 'danger' : 'success'); ?>">
                                                <?php echo e($transaction->type === 'debit' ? 'Borç' : 'Alacak'); ?>

                                            </span>
                                        </td>
                                        <td class="text-end">
                                            <span class="<?php echo e($transaction->type === 'debit' ? 'text-danger' : 'text-success'); ?>">
                                                <?php echo e($transaction->type === 'debit' ? '+' : '-'); ?>

                                                <?php echo e(Format::money($transaction->amount)); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/firms/show.blade.php ENDPATH**/ ?>