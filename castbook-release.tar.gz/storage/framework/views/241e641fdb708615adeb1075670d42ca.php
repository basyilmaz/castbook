<?php
    use App\Support\Format;
?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <h4 class="mb-0">Geciken Ödemeler</h4>
    <small class="text-muted">Vadesi geçmiş ve henüz kapanmamış faturalar.</small>
</div>

<?php echo $__env->make('reports._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Fatura</th>
                        <th>Firma</th>
                        <th>Fatura Tarihi</th>
                        <th>Vade Tarihi</th>
                        <th class="text-center">Gecikme (Gün)</th>
                        <th class="text-end">Tutar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>#<?php echo e($invoice->id); ?></td>
                            <td>
                                <a href="<?php echo e(route('firms.show', $invoice->firm)); ?>" class="text-decoration-none">
                                    <?php echo e($invoice->firm->name); ?>

                                </a>
                            </td>
                            <td><?php echo e($invoice->date?->format('d.m.Y')); ?></td>
                            <td><?php echo e($invoice->due_date?->format('d.m.Y') ?? '-'); ?></td>
                            <td class="text-center text-danger fw-semibold"><?php echo e($invoice->days_overdue); ?></td>
                            <td class="text-end text-danger"><?php echo e(Format::money($invoice->amount)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Geciken fatura bulunmadı.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/reports/overdues.blade.php ENDPATH**/ ?>