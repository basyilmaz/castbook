<?php
    use App\Support\Format;
?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="mb-4">
        <h3 class="fw-semibold">Genel Bakış</h3>
        <p class="text-muted mb-0">Cari durumunuzu hızlıca gözden geçirin.</p>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="bg-primary text-white rounded-circle p-3">
                        <i class="bi bi-cash-stack fs-4"></i>
                    </div>
                    <div>
                        <span class="text-muted text-uppercase small">Toplam Alacak</span>
                        <h4 class="fw-semibold mb-0">
                            <?php echo e(Format::money($metrics['total_receivable'])); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="bg-success text-white rounded-circle p-3">
                        <i class="bi bi-wallet2 fs-4"></i>
                    </div>
                    <div>
                        <span class="text-muted text-uppercase small">Bu Ayki Tahsilat</span>
                        <h4 class="fw-semibold mb-0">
                            <?php echo e(Format::money($metrics['monthly_collection'])); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="bg-danger text-white rounded-circle p-3">
                        <i class="bi bi-people-fill fs-4"></i>
                    </div>
                    <div>
                        <span class="text-muted text-uppercase small">Geciken Müşteri</span>
                        <h4 class="fw-semibold mb-0"><?php echo e($metrics['overdue_firm_count']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="bg-warning text-dark rounded-circle p-3">
                        <i class="bi bi-calendar-week fs-4"></i>
                    </div>
                    <div>
                        <span class="text-muted text-uppercase small">Yaklaşan Faturalar</span>
                        <h4 class="fw-semibold mb-0"><?php echo e($metrics['upcoming_invoice_count']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white">
            <h5 class="mb-0">Firma Durum Özeti</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Firma Adı</th>
                            <th class="text-end">Toplam Borç</th>
                            <th class="text-end">Toplam Tahsilat</th>
                            <th class="text-end">Kalan Bakiye</th>
                            <th class="text-center">Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $firms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($firm['name']); ?></td>
                                <td class="text-end"><?php echo e(Format::money($firm['total_debt'])); ?></td>
                                <td class="text-end"><?php echo e(Format::money($firm['total_collection'])); ?></td>
                                <td class="text-end <?php echo e($firm['remaining'] > 0 ? '' : 'text-success'); ?>">
                                    <?php echo e(Format::money($firm['remaining'])); ?>

                                </td>
                                <td class="text-center">
                                    <span class="badge bg-<?php echo e($firm['badge_class']); ?>">
                                        <?php echo e($firm['status_label']); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    Görüntülenecek firma bulunamadı.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/dashboard.blade.php ENDPATH**/ ?>