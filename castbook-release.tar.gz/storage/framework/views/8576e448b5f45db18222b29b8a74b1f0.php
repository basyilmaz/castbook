<?php
    use App\Support\Format;
?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <h4 class="mb-0">Aylık Tahsilat Raporu</h4>
    <small class="text-muted">Seçilen yıl için firma bazında tahsilat toplamları.</small>
</div>

<?php echo $__env->make('reports._tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<form method="GET" class="card border-0 shadow-sm mb-3">
    <div class="card-body row g-3 align-items-end">
        <div class="col-md-4">
            <label for="firm_id" class="form-label">Firma</label>
            <select name="firm_id" id="firm_id" class="form-select">
                <option value="">Tümü</option>
                <?php $__currentLoopData = $firms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($firm->id); ?>" <?php if($selectedFirm == $firm->id): echo 'selected'; endif; ?>><?php echo e($firm->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="year" class="form-label">Yıl</label>
            <select name="year" id="year" class="form-select">
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item); ?>" <?php if($year == $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="per_page" class="form-label">Sayfa Başına Kayıt</label>
            <select name="per_page" id="per_page" class="form-select">
                <?php $__currentLoopData = [6, 12, 24]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($size); ?>" <?php if($perPage === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-grid gap-2">
            <button type="submit" class="btn btn-primary">Filtrele</button>
            <a href="<?php echo e(route('reports.collections')); ?>" class="btn btn-light">Temizle</a>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Yıl İçi Toplam Tahsilat</small>
                <div class="h4 mb-0 text-success"><?php echo e(Format::money($totals['year_total'])); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <small class="text-muted text-uppercase">Tahsilat Sayısı</small>
                <div class="h4 mb-0"><?php echo e(number_format($totals['payment_count'], 0, ',', '.')); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Ay</th>
                        <th class="text-end">Tahsilat Toplamı</th>
                        <th class="text-end">İşlem Adedi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $monthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(Format::monthLabel($row->period)); ?></td>
                            <td class="text-end text-success"><?php echo e(Format::money($row->total_amount)); ?></td>
                            <td class="text-end"><?php echo e(number_format($row->payment_count, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted py-4">Veri bulunamadı.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer bg-white">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div class="text-muted small">
                Toplam <?php echo e($monthly->total()); ?> kayıt · Sayfa <?php echo e($monthly->currentPage()); ?> / <?php echo e($monthly->lastPage()); ?>

            </div>
            <?php echo e($monthly->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\YazilimProjeler\Muhasebe\resources\views/reports/collections.blade.php ENDPATH**/ ?>