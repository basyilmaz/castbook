<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FirmController;
use App\Http\Controllers\FirmPriceHistoryController;
use App\Http\Controllers\FirmStatementController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.attempt');
});

Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'time' => now()->toIso8601String(),
    ]);
});

Route::middleware(['auth', 'active'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::post('firms/{firm}/sync-invoices', [FirmController::class, 'syncInvoices'])->name('firms.sync-invoices');
    Route::post('firms/{firm}/statement', [FirmStatementController::class, 'generate'])->name('firms.statement');
    Route::post('firms/{firm}/price-histories', [FirmPriceHistoryController::class, 'store'])->name('firms.price-histories.store');
    Route::delete('firms/{firm}/price-histories/{priceHistory}', [FirmPriceHistoryController::class, 'destroy'])->name('firms.price-histories.destroy');
    Route::post('invoices/sync-monthly', [InvoiceController::class, 'syncMonthly'])->name('invoices.sync-monthly');
    Route::resource('firms', FirmController::class);
    Route::resource('invoices', InvoiceController::class);
    Route::resource('payments', PaymentController::class)->only(['index', 'create', 'store', 'destroy']);
    Route::get('settings', [SettingsController::class, 'edit'])->name('settings.edit');
    Route::put('settings', [SettingsController::class, 'update'])->name('settings.update');
    Route::post('settings/backup/download', [SettingsController::class, 'downloadBackup'])->name('settings.backup.download');
    Route::post('settings/backup/restore', [SettingsController::class, 'restoreBackup'])->name('settings.backup.restore');
    Route::get('settings/logo/{path}', [SettingsController::class, 'logo'])
        ->where('path', '.*')
        ->name('settings.logo');
    Route::get('settings/export/{type}', [SettingsController::class, 'exportCsv'])->name('settings.export.csv');

    Route::middleware('role:admin')->group(function () {
        Route::resource('users', UserController::class)->except(['show']);
    });

    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('balances', [ReportController::class, 'balances'])->name('balance');
        Route::get('collections', [ReportController::class, 'collections'])->name('collections');
        Route::get('overdues', [ReportController::class, 'overdues'])->name('overdues');
        Route::get('invoices', [ReportController::class, 'invoices'])->name('invoices');
    });
});
