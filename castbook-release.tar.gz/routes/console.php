<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;
use Illuminate\Support\Facades\Schema;
use App\Models\Setting;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

$invoiceDay = 1;

try {
    if (Schema::hasTable('settings')) {
        $invoiceDay = (int) Setting::getValue('invoice_day', '1');
    }
} catch (\Throwable $exception) {
    $invoiceDay = 1;
}

Schedule::command('app:generate-monthly-invoices')
    ->monthlyOn($invoiceDay, '08:00')
    ->description('Aktif firmalar icin aylik fatura olusturur');
