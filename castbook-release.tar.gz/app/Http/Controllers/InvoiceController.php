<?php

namespace App\Http\Controllers;

use App\Models\Firm;
use App\Models\Invoice;
use App\Models\Setting;
use App\Services\InvoiceGenerationService;
use App\Support\Format;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class InvoiceController extends Controller
{
    public function index(Request $request): View
    {
        $filters = $request->only(['status', 'firm_id', 'date_from', 'date_to', 'per_page']);
        $perPage = (int) ($filters['per_page'] ?? 10);

        if (! in_array($perPage, [10, 20, 50, 100], true)) {
            $perPage = 10;
        }

        $filters['per_page'] = $perPage;

        $invoices = Invoice::query()
            ->with('firm:id,name')
            ->withSum('payments', 'amount')
            ->when($filters['status'] ?? null, fn ($query, $status) => $query->where('status', $status))
            ->when($filters['firm_id'] ?? null, fn ($query, $firmId) => $query->where('firm_id', $firmId))
            ->when($filters['date_from'] ?? null, function ($query, $from) {
                try {
                    $start = Carbon::createFromFormat('Y-m-d', $from)->startOfDay();
                } catch (\Throwable $exception) {
                    return;
                }

                $query->where('date', '>=', $start);
            })
            ->when($filters['date_to'] ?? null, function ($query, $to) {
                try {
                    $end = Carbon::createFromFormat('Y-m-d', $to)->endOfDay();
                } catch (\Throwable $exception) {
                    return;
                }

                $query->where('date', '<=', $end);
            })
            ->latest('date')
            ->paginate($perPage)
            ->withQueryString();

        $firms = Firm::orderBy('name')->get(['id', 'name']);

        return view('invoices.index', [
            'invoices' => $invoices,
            'firms' => $firms,
            'filters' => $filters,
            'perPage' => $perPage,
        ]);
    }

    public function create(Request $request): View
    {
        $firms = Firm::active()->orderBy('name')->get(['id', 'name', 'monthly_fee']);
        $invoiceDate = Carbon::now()->startOfMonth();
        $dueDays = (int) Setting::getValue('invoice_default_due_days', 10);

        $invoice = new Invoice([
            'date' => $invoiceDate,
            'due_date' => $dueDays > 0 ? $invoiceDate->copy()->addDays($dueDays) : $invoiceDate->copy()->addDays(10),
            'amount' => 0,
            'description' => Setting::getValue('invoice_default_description', ''),
        ]);

        $prefillFirmId = $request->integer('firm_id') ?: old('firm_id');
        if ($prefillFirmId) {
            $firm = $firms->firstWhere('id', $prefillFirmId) ?? Firm::find($prefillFirmId);
            if ($firm) {
                $invoice->amount = $firm->priceForDate($invoiceDate);
            }
        }

        return view('invoices.create', compact('invoice', 'firms', 'prefillFirmId'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validatedData($request);

        $firm = Firm::find($data['firm_id']);
        $invoiceDate = Carbon::parse($data['date']);
        $expectedAmount = $firm?->priceForDate($invoiceDate) ?? 0.0;

        if (($data['amount'] ?? 0) <= 0 && $expectedAmount > 0) {
            $data['amount'] = $expectedAmount;
        }

        $invoice = Invoice::create($data);

        $description = $invoice->description ?: 'Aylık muhasebe ücreti';

        $invoice->transactions()->create([
            'firm_id' => $invoice->firm_id,
            'type' => 'debit',
            'amount' => $invoice->amount,
            'date' => $invoice->date,
            'description' => $description,
        ]);

        $redirect = redirect()
            ->route('invoices.show', $invoice)
            ->with('status', 'Fatura oluşturuldu ve cari borç kaydedildi.');

        if ($expectedAmount > 0 && abs($expectedAmount - $invoice->amount) > 0.01) {
            $redirect->with('warning', 'Uyarı: Bu tarih için standart ücret ' . Format::money($expectedAmount) . '.');
        }

        return $redirect;
    }

    public function show(Invoice $invoice): View
    {
        $invoice->load(['firm', 'payments'])->loadSum('payments', 'amount');

        return view('invoices.show', compact('invoice'));
    }

    public function edit(Invoice $invoice): View
    {
        if (in_array($invoice->status, ['paid', 'partial'], true)) {
            return redirect()->route('invoices.show', $invoice)
                ->withErrors(['invoice' => 'Ödenmiş veya kısmen ödenmiş faturalar düzenlenemez.']);
        }

        $firms = Firm::orderBy('name')->get(['id', 'name']);

        return view('invoices.edit', compact('invoice', 'firms'));
    }

    public function update(Request $request, Invoice $invoice): RedirectResponse
    {
        if (in_array($invoice->status, ['paid', 'partial'], true)) {
            return redirect()->route('invoices.show', $invoice)
                ->withErrors(['invoice' => 'Ödenmiş veya kısmen ödenmiş faturalar düzenlenemez.']);
        }

        $data = $this->validatedData($request, $invoice);

        $invoice->update($data);

        $transaction = $invoice->transactions()->first();
        if ($transaction) {
            $transaction->update([
                'amount' => $invoice->amount,
                'date' => $invoice->date,
                'description' => $invoice->description ?? $transaction->description,
            ]);
        } else {
            $invoice->transactions()->create([
                'firm_id' => $invoice->firm_id,
                'type' => 'debit',
                'amount' => $invoice->amount,
                'date' => $invoice->date,
                'description' => $invoice->description ?? 'Aylık muhasebe ücreti',
            ]);
        }

        $expectedAmount = $invoice->firm?->priceForDate(Carbon::parse($invoice->date)) ?? 0.0;

        $redirect = redirect()
            ->route('invoices.show', $invoice)
            ->with('status', 'Fatura güncellendi.');

        if ($expectedAmount > 0 && abs($expectedAmount - $invoice->amount) > 0.01) {
            $redirect->with('warning', 'Uyarı: Bu tarih için standart ücret ' . Format::money($expectedAmount) . '.');
        }

        if ($invoice->payments()->exists()) {
            $invoice->refreshPaymentStatus();
        }

        return $redirect;
    }

    public function destroy(Invoice $invoice): RedirectResponse
    {
        if (in_array($invoice->status, ['paid', 'partial'], true)) {
            return redirect()
                ->route('invoices.show', $invoice)
                ->withErrors(['invoice' => 'Ödenmiş veya kısmen ödenmiş faturalar silinemez.']);
        }

        $invoice->transactions()->delete();
        $invoice->delete();

        return redirect()
            ->route('invoices.index')
            ->with('status', 'Fatura silindi.');
    }

    public function syncMonthly(Request $request, InvoiceGenerationService $generator): RedirectResponse
    {
        $month = $request->input('month');

        try {
            $target = $month
                ? Carbon::createFromFormat('Y-m', $month)->startOfMonth()
                : Carbon::now()->startOfMonth();
        } catch (\Throwable $exception) {
            return back()->withErrors(['month' => 'Geçersiz ay formatı.']);
        }

        $firms = Firm::active()->get();
        $created = 0;

        foreach ($firms as $firm) {
            $invoice = $generator->ensureMonthlyInvoice($firm, $target);
            if ($invoice) {
                $created++;
            }
        }

        $labelDate = $generator->invoiceDateForMonth($target)->format('m/Y');
        $message = $created > 0
            ? "{$labelDate} döneminde {$created} fatura oluşturuldu."
            : "{$labelDate} dönemi için yeni fatura oluşturulmadı.";

        return back()->with('status', $message);
    }

    protected function validatedData(Request $request, ?Invoice $invoice = null): array
    {
        $data = $request->validate([
            'firm_id' => ['required', 'exists:firms,id'],
            'date' => ['required', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:date'],
            'amount' => ['required', 'numeric', 'min:0'],
            'description' => ['nullable', 'string', 'max:255'],
            'official_number' => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('invoices', 'official_number')->ignore($invoice?->id),
            ],
            'status' => ['nullable', 'in:unpaid,partial,paid,cancelled'],
        ]);

        $data['status'] = $data['status'] ?? 'unpaid';
        $data['description'] = $data['description'] ?? Setting::getValue('invoice_default_description', '');

        if (empty($data['due_date'])) {
            $dueDays = (int) Setting::getValue('invoice_default_due_days', 0);
            if ($dueDays > 0) {
                $data['due_date'] = Carbon::parse($data['date'])->addDays($dueDays)->format('Y-m-d');
            }
        }

        return $data;
    }
}
