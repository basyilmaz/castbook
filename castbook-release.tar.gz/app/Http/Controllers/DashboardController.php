<?php

namespace App\Http\Controllers;

use App\Models\Firm;
use App\Models\Invoice;
use App\Models\Payment;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $now = Carbon::now();

        $firms = Firm::query()
            ->withSum(['transactions as debit_total' => fn ($query) => $query->where('type', 'debit')], 'amount')
            ->withSum(['transactions as credit_total' => fn ($query) => $query->where('type', 'credit')], 'amount')
            ->with(['invoices' => fn ($query) => $query->whereIn('status', ['unpaid', 'partial'])->select('id', 'firm_id', 'date', 'due_date', 'status')])
            ->orderBy('name')
            ->get();

        $totalReceivable = 0;
        $overdueFirmCount = 0;

        $firmRows = $firms->map(function (Firm $firm) use ($now, &$totalReceivable, &$overdueFirmCount) {
            $totalDebt = (float) ($firm->debit_total ?? 0);
            $totalCollection = (float) ($firm->credit_total ?? 0);
            $remaining = $totalDebt - $totalCollection;

            $hasOverdueInvoice = $firm->invoices->contains(function ($invoice) use ($now) {
                $dueDate = $invoice->due_date ?? $invoice->date;
                return $dueDate ? Carbon::parse($dueDate)->isBefore($now->startOfDay()) : false;
            });

            $hasPartialInvoice = $firm->invoices->contains(fn ($invoice) => $invoice->status === 'partial');

            if ($remaining <= 0) {
                $statusLabel = 'Ödendi';
                $badgeClass = 'success';
            } elseif ($hasOverdueInvoice) {
                $statusLabel = 'Gecikmiş';
                $badgeClass = 'danger';
                $overdueFirmCount++;
            } elseif ($hasPartialInvoice) {
                $statusLabel = 'Kısmi Ödeme';
                $badgeClass = 'warning text-dark';
            } else {
                $statusLabel = 'Bekliyor';
                $badgeClass = 'warning text-dark';
            }

            $totalReceivable += max($remaining, 0);

            return [
                'name' => $firm->name,
                'total_debt' => $totalDebt,
                'total_collection' => $totalCollection,
                'remaining' => $remaining,
                'status_label' => $statusLabel,
                'badge_class' => $badgeClass,
            ];
        });

        $monthlyCollection = (float) Payment::whereBetween('date', [
            $now->copy()->startOfMonth(),
            $now->copy()->endOfMonth(),
        ])->sum('amount');

        $upcomingInvoicesCount = Invoice::whereIn('status', ['unpaid', 'partial'])
            ->where(function ($query) use ($now) {
                $query->whereBetween('due_date', [
                    $now->copy()->startOfDay(),
                    $now->copy()->addDays(7)->endOfDay(),
                ])->orWhere(function ($inner) use ($now) {
                    $inner->whereNull('due_date')
                        ->whereBetween('date', [
                            $now->copy()->startOfDay(),
                            $now->copy()->addDays(7)->endOfDay(),
                        ]);
                });
            })
            ->count();

        $metrics = [
            'total_receivable' => $totalReceivable,
            'monthly_collection' => $monthlyCollection,
            'overdue_firm_count' => $overdueFirmCount,
            'upcoming_invoice_count' => $upcomingInvoicesCount,
        ];

        return view('dashboard', [
            'metrics' => $metrics,
            'firms' => $firmRows,
        ]);
    }
}
