<?php

namespace App\Http\Controllers;

use App\Models\Firm;
use App\Models\Invoice;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class ReportController extends Controller
{
    public function balances(Request $request): View
    {
        $status = $request->get('status');
        $perPage = $this->perPage($request->integer('per_page'), [10, 25, 50, 100], 25);

        $baseQuery = Firm::query()
            ->select('firms.*')
            ->when($status, fn ($query) => $query->where('status', $status));

        $transactionTotals = DB::table('transactions')
            ->selectRaw('firm_id,
                SUM(CASE WHEN type = "debit" THEN amount ELSE 0 END) AS debit_total,
                SUM(CASE WHEN type = "credit" THEN amount ELSE 0 END) AS credit_total')
            ->groupBy('firm_id');

        $firms = (clone $baseQuery)
            ->leftJoinSub($transactionTotals, 'tx', fn ($join) => $join->on('tx.firm_id', '=', 'firms.id'))
            ->selectRaw('COALESCE(tx.debit_total, 0) AS debit_total')
            ->selectRaw('COALESCE(tx.credit_total, 0) AS credit_total')
            ->orderBy('firms.name')
            ->paginate($perPage)
            ->through(function ($firm) {
                $firm->balance_total = (float) $firm->debit_total - (float) $firm->credit_total;
                return $firm;
            })
            ->withQueryString();

        $totalsRow = DB::table('transactions')
            ->join('firms', 'firms.id', '=', 'transactions.firm_id')
            ->when($status, fn ($query) => $query->where('firms.status', $status))
            ->selectRaw('
                SUM(CASE WHEN transactions.type = "debit" THEN transactions.amount ELSE 0 END) AS debit_total,
                SUM(CASE WHEN transactions.type = "credit" THEN transactions.amount ELSE 0 END) AS credit_total
            ')
            ->first();

        $totals = [
            'debit' => (float) ($totalsRow->debit_total ?? 0),
            'credit' => (float) ($totalsRow->credit_total ?? 0),
            'balance' => (float) ($totalsRow->debit_total ?? 0) - (float) ($totalsRow->credit_total ?? 0),
        ];

        return view('reports.balances', compact('firms', 'totals', 'status', 'perPage'));
    }

    public function collections(Request $request): View
    {
        $selectedFirm = $request->integer('firm_id') ?: null;
        $year = $request->integer('year') ?: Carbon::now()->year;
        $perPage = $this->perPage($request->integer('per_page'), [6, 12, 24], 12);

        $paymentsQuery = Payment::query()
            ->selectRaw("DATE_FORMAT(date, '%Y-%m') AS period")
            ->selectRaw('SUM(amount) AS total_amount')
            ->selectRaw('COUNT(*) AS payment_count')
            ->when($selectedFirm, fn ($query, $firmId) => $query->where('firm_id', $firmId))
            ->whereYear('date', $year)
            ->groupBy('period')
            ->orderByDesc('period');

        $monthly = $paymentsQuery
            ->paginate($perPage)
            ->withQueryString();

        $totalsRow = Payment::query()
            ->when($selectedFirm, fn ($query, $firmId) => $query->where('firm_id', $firmId))
            ->whereYear('date', $year)
            ->selectRaw('SUM(amount) AS total_amount, COUNT(*) AS payment_count')
            ->first();

        $firms = Firm::orderBy('name')->select('id', 'name')->get();
        $years = collect(range(Carbon::now()->year - 5, Carbon::now()->year))->sortDesc();

        $totals = [
            'year_total' => (float) ($totalsRow->total_amount ?? 0),
            'payment_count' => (int) ($totalsRow->payment_count ?? 0),
        ];

        return view('reports.collections', compact(
            'monthly',
            'firms',
            'selectedFirm',
            'year',
            'years',
            'totals',
            'perPage'
        ));
    }

    public function overdues(): View
    {
        $today = Carbon::today();

        $invoices = Invoice::query()
            ->with('firm')
            ->whereIn('status', ['unpaid', 'partial'])
            ->where(function ($query) use ($today) {
                $query->whereNotNull('due_date')
                    ->where('due_date', '<', $today)
                    ->orWhere(function ($inner) use ($today) {
                        $inner->whereNull('due_date')->where('date', '<', $today);
                    });
            })
            ->orderBy('due_date')
            ->orderBy('date')
            ->get()
            ->map(function ($invoice) use ($today) {
                $reference = $invoice->due_date ?? $invoice->date;
                $invoice->days_overdue = $reference?->diffInDays($today) ?? 0;
                return $invoice;
            });

        return view('reports.overdues', compact('invoices', 'today'));
    }

    public function invoices(Request $request): View
    {
        $selectedFirm = $request->integer('firm_id') ?: null;
        $year = $request->integer('year') ?: Carbon::now()->year;
        $perPage = $this->perPage($request->integer('per_page'), [10, 25, 50, 100], 25);

        $baseQuery = Invoice::query()
            ->when($selectedFirm, fn ($query, $firmId) => $query->where('firm_id', $firmId))
            ->whereYear('date', $year);

        $summaryRow = (clone $baseQuery)
            ->selectRaw('COUNT(*) AS count')
            ->selectRaw('SUM(amount) AS total_amount')
            ->selectRaw('SUM(CASE WHEN status = "paid" THEN amount ELSE 0 END) AS paid_amount')
            ->selectRaw('SUM(CASE WHEN status = "unpaid" THEN amount ELSE 0 END) AS unpaid_amount')
            ->first();

        $statusBreakdown = (clone $baseQuery)
            ->select('status')
            ->selectRaw('COUNT(*) AS count')
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        $invoices = (clone $baseQuery)
            ->with('firm:id,name')
            ->orderByDesc('date')
            ->paginate($perPage)
            ->withQueryString();

        $firms = Firm::orderBy('name')->select('id', 'name')->get();
        $years = collect(range(Carbon::now()->year - 5, Carbon::now()->year))->sortDesc();

        $summary = [
            'count' => (int) ($summaryRow->count ?? 0),
            'total_amount' => (float) ($summaryRow->total_amount ?? 0),
            'paid_amount' => (float) ($summaryRow->paid_amount ?? 0),
            'unpaid_amount' => (float) ($summaryRow->unpaid_amount ?? 0),
        ];

        return view('reports.invoices', compact(
            'invoices',
            'summary',
            'statusBreakdown',
            'firms',
            'selectedFirm',
            'year',
            'years',
            'perPage'
        ));
    }

    private function perPage(?int $requested, array $allowed, int $default): int
    {
        if (! $requested || ! in_array($requested, $allowed, true)) {
            return $default;
        }

        return $requested;
    }
}
