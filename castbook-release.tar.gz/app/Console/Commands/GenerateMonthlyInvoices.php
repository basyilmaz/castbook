<?php

namespace App\Console\Commands;

use App\Mail\MonthlyInvoiceSummary;
use App\Models\Firm;
use App\Models\Setting;
use App\Services\InvoiceGenerationService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;

class GenerateMonthlyInvoices extends Command
{
    protected $signature = 'app:generate-monthly-invoices {--month=}';

    protected $description = 'Aktif firmalar icin aylik muhasebe faturalarini olusturur';

    public function handle(): int
    {
        $targetMonth = $this->option('month');

        try {
            $period = $targetMonth
                ? Carbon::createFromFormat('Y-m', $targetMonth)->startOfMonth()
                : Carbon::now()->startOfMonth();
        } catch (\Exception $exception) {
            $this->error('Gecersiz ay formati. Ornek kullanim: --month=2025-10');
            return self::INVALID;
        }

        $generator = new InvoiceGenerationService();
        $firms = Firm::active()->get();

        $createdCount = 0;
        $createdInvoices = [];
        $totalAmount = 0.0;

        foreach ($firms as $firm) {
            $invoice = $generator->ensureMonthlyInvoice($firm, $period);

            if ($invoice) {
                $createdCount++;
                $createdInvoices[] = [
                    'invoice_id' => $invoice->id,
                    'firm_name' => $firm->name,
                    'amount' => (float) $invoice->amount,
                    'date' => $invoice->date,
                ];
                $totalAmount += (float) $invoice->amount;
            }
        }

        $labelDate = $generator->invoiceDateForMonth($period);
        $this->info("{$labelDate->format('m/Y')} dönemi için {$createdCount} fatura oluşturuldu.");

        if ($createdCount > 0 && Setting::getValue('invoice_auto_notify', '0') === '1') {
            $recipients = Setting::getInvoiceNotificationRecipients();

            if (! empty($recipients)) {
                Mail::to($recipients)->send(new MonthlyInvoiceSummary(
                    $period,
                    $createdCount,
                    $createdInvoices,
                    $totalAmount
                ));

                $this->info('Bildirim e-postası gönderildi.');
            } else {
                $this->warn('Bildirim etkin ancak alıcı listesi tanımlı değil.');
            }
        }

        return self::SUCCESS;
    }
}
