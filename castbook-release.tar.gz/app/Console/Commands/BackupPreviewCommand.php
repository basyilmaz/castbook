<?php

namespace App\Console\Commands;

use App\Services\BackupEncryptionService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Console\Command\Command as SymfonyCommand;

class BackupPreviewCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'backup:preview
        {file : Ön izlenecek yedek dosyası yolu}
        {--password= : Şifreli yedekler için parola}
        {--format=table : Çıktı formatı (table, json)}
        {--json : Çıktıyı JSON formatında yazdırır (eski seçenek)}
        {--log= : Çıktıyı belirtilen dosyaya da yaz}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Yedek dosyasını şifre çözerek analiz eder ve kayıt sayılarını listeler.';

    public function __construct(private readonly BackupEncryptionService $encryptionService)
    {
        parent::__construct();
    }

    public function handle(): int
    {
        $path = $this->argument('file');
        $password = $this->option('password');

        if (! file_exists($path)) {
            $this->error("Dosya bulunamadı: {$path}");

            return SymfonyCommand::FAILURE;
        }

        $contents = file_get_contents($path);

        if ($contents === false) {
            $this->error('Dosya okunamadı.');

            return SymfonyCommand::FAILURE;
        }

        $decoded = json_decode($contents, true);

        if (! is_array($decoded)) {
            $this->error('JSON formatı geçersiz.');

            return SymfonyCommand::FAILURE;
        }

        if (($decoded['meta']['encrypted'] ?? false) === true) {
            if (empty($password)) {
                $this->error('Şifreli yedek için --password seçeneğini kullanmalısınız.');

                return SymfonyCommand::FAILURE;
            }

            try {
                $decoded = $this->encryptionService->decrypt($decoded, $password);
            } catch (\Throwable $exception) {
                $this->error('Şifre çözme başarısız: ' . $exception->getMessage());

                return SymfonyCommand::FAILURE;
            }
        }

        if (! isset($decoded['data']) || ! is_array($decoded['data'])) {
            $this->error('Yedek yapısı beklenen formatta değil.');

            return SymfonyCommand::FAILURE;
        }

        $counts = collect($decoded['data'])->map(fn ($items) => is_array($items) ? count($items) : 0);
        $payload = [
            'meta' => $decoded['meta'] ?? [],
            'counts' => $counts->toArray(),
        ];

        $format = strtolower((string) ($this->option('format') ?: 'table'));

        if ($this->option('json')) {
            $format = 'json';
        }

        if (! in_array($format, ['table', 'json'], true)) {
            $this->error('Geçersiz format. table veya json kullanın.');

            return SymfonyCommand::FAILURE;
        }

        $logPath = $this->option('log');

        if ($format === 'json') {
            $output = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $this->line($output);
            $this->writeLog($logPath, $output . PHP_EOL);

            return SymfonyCommand::SUCCESS;
        }

        $this->table(
            ['Tablo', 'Kayıt Sayısı'],
            $counts->map(fn ($count, $table) => [ucfirst($table), $count])->all()
        );

        if ($logPath) {
            $tableLines = collect($counts)->map(fn ($count, $table) => sprintf('%s: %d', ucfirst($table), $count));
            $content = implode(PHP_EOL, $tableLines->all()) . PHP_EOL;
            $this->writeLog($logPath, $content);
            $this->info("Çıktı {$logPath} dosyasına yazıldı.");
        }

        $this->info('Ön izleme tamamlandı.');

        return SymfonyCommand::SUCCESS;
    }

    private function writeLog(?string $path, string $contents): void
    {
        if (empty($path)) {
            return;
        }

        try {
            file_put_contents($path, $contents, FILE_APPEND | LOCK_EX);
        } catch (\Throwable $exception) {
            $this->warn('Log dosyasına yazılamadı: ' . $exception->getMessage());
        }
    }
}
