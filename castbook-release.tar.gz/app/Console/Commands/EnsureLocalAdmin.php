<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\Console\Command\Command as SymfonyCommand;

class EnsureLocalAdmin extends Command
{
    protected $signature = 'user:ensure-admin
        {--email=admin@example.com : Oluşturulacak/güncellenecek admin e-posta adresi}
        {--password=admin123 : Admin kullanıcısının parolası}
        {--name=Yerel Admin : Admin kullanıcısının adı}';

    protected $description = 'Geliştirme ortamı için admin hesabı oluşturur veya günceller.';

    public function handle(): int
    {
        $email = (string) $this->option('email');
        $password = (string) $this->option('password');
        $name = (string) $this->option('name');

        if (strlen($password) < 6) {
            $this->error('Parola en az 6 karakter olmalı.');

            return SymfonyCommand::FAILURE;
        }

        $user = User::firstOrNew(['email' => $email]);

        $user->name = $name;
        $user->role = 'admin';
        $user->is_active = true;
        $user->email_verified_at = now();
        $user->password = Hash::make($password);

        $user->save();

        $this->info("Admin hesabı hazır: {$email}");
        $this->line("Parola: {$password}");

        return SymfonyCommand::SUCCESS;
    }
}
