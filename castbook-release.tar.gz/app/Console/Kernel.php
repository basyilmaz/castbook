<?php

namespace App\Console;

use App\Console\Commands\BackupPreviewCommand;
use App\Console\Commands\EnsureLocalAdmin;
use App\Console\Commands\GenerateMonthlyInvoices;
use App\Console\Commands\SyncHistoricalInvoices;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // Gelecekteki cron görevleri burada tanımlanabilir.
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');

        $this->commands([
            BackupPreviewCommand::class,
            GenerateMonthlyInvoices::class,
            EnsureLocalAdmin::class,
            SyncHistoricalInvoices::class,
        ]);
    }
}
