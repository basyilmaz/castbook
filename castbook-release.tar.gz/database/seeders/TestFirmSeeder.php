<?php

namespace Database\Seeders;

use App\Models\Firm;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class TestFirmSeeder extends Seeder
{
    public function run(): void
    {
        $baseNames = [
            'Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon',
            'Zeta', 'Eta', 'Theta', 'Iota', 'Kappa',
            'Lambda', 'Mu', 'Nu', 'Xi', 'Omicron',
            'Pi', 'Rho', 'Sigma', 'Tau', 'Upsilon',
        ];

        $fees = [
            750, 980, 1250, 1600, 1850,
            2100, 2350, 2600, 2850, 3100,
            3350, 3600, 3850, 4100, 4350,
            4600, 4850, 5100, 5350, 5600,
        ];

        $dates = [
            '2021-01-01', '2021-05-01', '2021-09-01', '2022-01-01', '2022-04-01',
            '2022-08-01', '2022-12-01', '2023-02-01', '2023-05-01', '2023-09-01',
            '2023-12-01', '2024-02-01', '2024-05-01', '2024-08-01', '2024-11-01',
            '2025-01-01', '2025-03-01', '2025-05-01', '2025-07-01', '2025-09-01',
        ];

        foreach ($baseNames as $index => $name) {
            Firm::updateOrCreate(
                ['name' => "Test {$name} Firma"],
                [
                    'tax_no' => 'TEST' . str_pad((string) ($index + 1), 6, '0', STR_PAD_LEFT),
                    'contact_person' => "{$name} Yetkili",
                    'contact_email' => strtolower($name) . '@example.com',
                    'contact_phone' => '555' . str_pad((string) rand(1000000, 9999999), 7, '0', STR_PAD_LEFT),
                    'monthly_fee' => min(max($fees[$index], 500), 5000),
                    'status' => 'active',
                    'contract_start_at' => Carbon::parse($dates[$index]),
                    'notes' => 'Otomatik olusturulan test firmasi',
                ]
            );
        }
    }
}
